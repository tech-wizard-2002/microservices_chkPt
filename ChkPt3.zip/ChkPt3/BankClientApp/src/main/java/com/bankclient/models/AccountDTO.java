package com.bankclient.models;

import java.util.List;



public class AccountDTO {

	private List<Account> list;

	@Override
	public String toString() {
		return "accountDTO [list=" + list + "]";
	}

	public List<Account> getList() {
		return list;
	}

	public void setList(List<Account> list) {
		this.list = list;
	}
}
