package com.bankclient.BankClientApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankClientAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
